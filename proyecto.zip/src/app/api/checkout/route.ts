// src/app/api/checkout/route.ts

import { NextResponse } from 'next/server';
import axios from 'axios'; // Importa axios para realizar solicitudes HTTP

export async function GET(req: Request) {
    return NextResponse.json({ message: 'Checkout API funcionando' });
}

export async function POST(req: Request) {
    try {
        const data = await req.json();
        
        // Llama a la función que procesa el pago
        const paymentResult = await processPayment(data);

        return NextResponse.json({ message: 'Pago procesado correctamente', paymentResult });
    } catch (error) {
        console.error('Error al procesar el pago:', error);
        return NextResponse.json({ error: 'Error al procesar el pago' }, { status: 500 });
    }
}

// Función que procesa el pago con Redsys
async function processPayment(data: any) {
    const paymentEndpoint = 'https://sis-t.redsys.es:25443/sis/NC/sandbox'; // URL para el entorno de pruebas de Redsys

    // Configura el cuerpo de la solicitud según la documentación de Redsys
    const body = {
        fuc: "123456789", // Cambia esto por tu FUC real
        terminal: "1",
        order: data.order, // El order que envíes desde el cliente
        amount: data.amount, // Monto del pago en céntimos
        currency: "978", // 978 es el código para el euro
        // Otros parámetros según lo que necesites enviar
    };

    try {
        // Realiza la solicitud POST a la API de Redsys
        const response = await axios.post(paymentEndpoint, body);
        
        // Maneja la respuesta de Redsys
        if (response.data) {
            return { status: 'success', data: response.data };
        } else {
            throw new Error('No se recibió respuesta válida de Redsys');
        }
    } catch (error) {
        console.error('Error al procesar el pago con Redsys:', error);
        throw new Error('Error al procesar el pago');
    }
}
