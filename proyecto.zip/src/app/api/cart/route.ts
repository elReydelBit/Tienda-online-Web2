// src/app/api/cart/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// Obtener los ítems del carrito
export async function GET(req: Request) {
  const userId = req.headers.get('userId'); // Obtenemos el userId desde los headers

  if (!userId) {
    return NextResponse.json({ message: 'Falta el userId en los headers' }, { status: 400 });
  }

  try {
    // Buscamos el carrito del usuario con los items relacionados
    const cart = await prisma.cart.findUnique({
      where: { userId: Number(userId) },
      include: { items: true },
    });

    if (!cart) {
      return NextResponse.json({ message: 'Carrito no encontrado' }, { status: 404 });
    }

    return NextResponse.json(cart);
  } catch (error) {
    console.error('Error al obtener el carrito:', error);
    return NextResponse.json({ message: 'Error interno del servidor' }, { status: 500 });
  }
}

// Añadir un ítem al carrito
export async function POST(req: Request) {
  const { userId, productId, quantity } = await req.json();

  if (!userId || !productId || !quantity) {
    return NextResponse.json({ message: 'Faltan parámetros' }, { status: 400 });
  }

  try {
    // Primero, intenta encontrar el carrito del usuario
    let cart = await prisma.cart.findUnique({
      where: { userId: Number(userId) },
    });

    // Si el carrito no existe, créalo
    if (!cart) {
      cart = await prisma.cart.create({
        data: {
          userId: Number(userId),
        },
      });
    }

    // Si el carrito existe, usa upsert en los items
    await prisma.cartItem.upsert({
      where: { cartId_productId: { cartId: cart.id, productId: Number(productId) } },
      update: { quantity: { increment: quantity } },
      create: { productId: Number(productId), quantity, cartId: cart.id },
    });

    // Devuelve el carrito actualizado
    const updatedCart = await prisma.cart.findUnique({
      where: { id: cart.id },
      include: { items: true },
    });

    return NextResponse.json(updatedCart);
  } catch (error) {
    console.error('Error al añadir al carrito:', error);
    return NextResponse.json({ message: 'Error interno del servidor' }, { status: 500 });
  }
}
