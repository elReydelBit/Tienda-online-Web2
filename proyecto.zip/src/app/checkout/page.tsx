'use client'; // Debe estar en la primera línea del archivo

import { useEffect } from 'react';
import Layout from '../components/Layout'; // Asegúrate de que la ruta sea correcta

// Declara el tipo de la función externa para que TypeScript la reconozca
declare global {
    interface Window {
        getInSiteFormJSON: (config: any) => void; // Aquí estamos diciendo que existe la función en window
    }
}

export default function CheckoutPage() {
    useEffect(() => {
        const loadRedsysScript = () => {
            const script = document.createElement('script');
            script.src = "https://sis-t.redsys.es:25443/sis/NC/sandbox/redsysV3.js"; // Entorno de pruebas
            script.async = true;
            document.body.appendChild(script);

            script.onload = () => {
                const insiteJSON = {
                    id: "card-form",
                    fuc: "123456789",  // Cambia este valor por tu FUC real
                    terminal: "1",
                    order: "ped4227", // Cambia esto por un valor único para cada pedido
                    estiloInsite: "inline"
                };

                // Accede a la función dentro de window
                if (window.getInSiteFormJSON) {
                    window.getInSiteFormJSON(insiteJSON);
                } else {
                    console.error("La función getInSiteFormJSON no está disponible");
                }
            };
        };

        loadRedsysScript();
    }, []);

    return (
        <Layout>
            <div className="container mx-auto py-20">
                <div id="card-form" className="border p-4 rounded-lg shadow-lg"></div>

                <input type="hidden" id="token" />
                <input type="hidden" id="errorCode" />

                <script>
                    {`
                        function merchantValidationEjemplo(){
                            return true;
                        }

                        window.addEventListener("message", function receiveMessage(event) {
                            storeIdOper(event, "token", "errorCode", merchantValidationEjemplo);
                        });
                    `}
                </script>
            </div>
        </Layout>
    );
}
