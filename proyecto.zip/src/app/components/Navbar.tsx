'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import jwt from 'jsonwebtoken';
import { FaShoppingCart, FaHome } from 'react-icons/fa';
import { FiUser } from 'react-icons/fi';

interface User {
  id: string;
  name: string;
}

export default function NavBar() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [logoutMessage, setLogoutMessage] = useState('');
  const [cartCount, setCartCount] = useState(0);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const decoded = jwt.decode(token) as User;
        if (decoded) {
          setUser(decoded);
          setIsAuthenticated(true);
          // Llamar a la función para cargar el número de productos en el carrito de la base de datos
          fetchCartCount(decoded.id);
        }
      } catch (error) {
        console.error("Token inválido:", error);
        setIsAuthenticated(false);
      }
    }
  }, []);

  const fetchCartCount = async (userId: string) => {
    try {
      const response = await fetch(`/api/cart?userId=${userId}`);
      const cart = await response.json();
      // Sumar la cantidad de productos en la cesta
      const totalCount = cart.items.reduce((acc: number, item: { quantity: number }) => acc + item.quantity, 0);
      setCartCount(totalCount);
    } catch (error) {
      console.error("Error al obtener la cesta:", error);
    }
  };

  const handleLogout = () => {
    if (user) {
      const userName = user.name;
      localStorage.removeItem('token');
      setIsAuthenticated(false);
      setUser(null);
      setLogoutMessage(`Adiós, ${userName}`);

      setTimeout(() => {
        setLogoutMessage('');
        router.push('/');
      }, 3000);
    }
  };

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const getTitleByPath = (path: string) => {
    switch (path) {
      case '/':
        return 'Bienvenido a la tienda';
      case '/shop':
        return 'Nuestra tienda';
      case '/checkout':
        return 'Pasarela de pago';
      case '/cart':
        return 'Cesta';
      default:
        return 'Tienda';
    }
  };

  return (
    <nav className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 p-6 text-white shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="text-2xl font-bold hover:underline">
            {getTitleByPath(pathname)}
          </Link>
        </div>

        <div className="flex items-center space-x-8">
          <Link href="/">
            <FaHome className="text-2xl hover:text-gray-300 cursor-pointer" />
          </Link>

          {isAuthenticated ? (
            <>
              <Link href="/cart" className="flex items-center">
                <span className="mr-2">Cesta</span>
                <div className="relative">
                  <FaShoppingCart className="text-2xl hover:text-gray-300 cursor-pointer" />
                  {cartCount > 0 && (
                    <span className="absolute top-[-0.5rem] right-[-0.5rem] bg-red-600 text-white text-xs font-bold rounded-full px-1">
                      {cartCount}
                    </span>
                  )}
                </div>
              </Link>

              <div className="relative">
                <div
                  className="flex items-center cursor-pointer space-x-2"
                  onClick={toggleDropdown}
                >
                  <FiUser className="text-2xl" />
                  <span>{user?.name}</span>
                </div>

                {dropdownOpen && (
                  <div className="absolute right-0 mt-2 w-40 bg-white text-black rounded-md shadow-lg">
                    <Link href="/profile" className="block px-4 py-2 hover:bg-gray-100">
                      Perfil
                    </Link>
                    <Link href="/settings" className="block px-4 py-2 hover:bg-gray-100">
                      Ajustes
                    </Link>
                    <button
                      className="block w-full text-left px-4 py-2 hover:bg-gray-100"
                      onClick={handleLogout}
                    >
                      Cerrar sesión
                    </button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <>
              <Link href="/login" className="text-xl hover:underline">
                Iniciar sesión
              </Link>
              <Link href="/signup" className="text-xl hover:underline">
                Registrarse
              </Link>
            </>
          )}
        </div>
      </div>

      {logoutMessage && <p className="mt-2 text-center text-red-300">{logoutMessage}</p>}
    </nav>
  );
}
