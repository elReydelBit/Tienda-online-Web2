'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Layout from '../components/Layout';
import Script from 'next/script';
import { REDSYS_CONFIG } from '@/lib/redsys-config';
import { generateRedsysSignature } from '@/lib/redsys-utils';

declare global {
  interface Window {
    getInSiteFormJSON: (config: any) => void;
    storeIdOper: (event: MessageEvent, tokenId: string, errorCodeId: string, merchantValidation: () => boolean) => void;
  }
}

interface CheckoutData {
  cartItems: any[];
  total: number;
  timestamp: number;
}

export default function CheckoutPage() {
  const router = useRouter();
  const [orderId, setOrderId] = useState('');
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const [formInitialized, setFormInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checkoutData, setCheckoutData] = useState<CheckoutData | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    // Recuperar y validar datos del checkout
    const storedCheckoutData = localStorage.getItem('checkoutData');
    if (!storedCheckoutData) {
      router.push('/cart');
      return;
    }

    try {
      const parsedData = JSON.parse(storedCheckoutData);
      // Verificar si los datos tienen más de 30 minutos
      if (Date.now() - parsedData.timestamp > 30 * 60 * 1000) {
        localStorage.removeItem('checkoutData');
        router.push('/cart');
        return;
      }

      setCheckoutData(parsedData);
      // Genera un ID de pedido único basado en timestamp
      const newOrderId = `PED${Date.now()}`;
      setOrderId(newOrderId);
    } catch (err) {
      console.error('Error parsing checkout data:', err);
      router.push('/cart');
    }
  }, [router]);

  useEffect(() => {
    if (scriptLoaded && orderId && checkoutData && !formInitialized) {
      initializeRedsysForm();
    }
  }, [scriptLoaded, orderId, checkoutData, formInitialized]);

  const initializeRedsysForm = () => {
    if (!checkoutData || !orderId) return;

    try {
      const totalInCents = Math.round(checkoutData.total * 100);
      
      if (typeof window.getInSiteFormJSON === 'function') {
        const merchantParams = {
          DS_MERCHANT_AMOUNT: totalInCents.toString(),
          DS_MERCHANT_ORDER: orderId,
          DS_MERCHANT_MERCHANTCODE: REDSYS_CONFIG.merchantCode,
          DS_MERCHANT_CURRENCY: REDSYS_CONFIG.currency,
          DS_MERCHANT_TRANSACTIONTYPE: REDSYS_CONFIG.transactionType,
          DS_MERCHANT_TERMINAL: REDSYS_CONFIG.terminal,
          DS_MERCHANT_MERCHANTURL: `${window.location.origin}/api/redsys/notify`,
          DS_MERCHANT_URLOK: `${window.location.origin}/success`,
          DS_MERCHANT_URLKO: `${window.location.origin}/error`,
          DS_MERCHANT_MERCHANTNAME: REDSYS_CONFIG.merchantName,
          DS_MERCHANT_TITULAR: REDSYS_CONFIG.titular,
          DS_MERCHANT_CONSUMERLANGUAGE: "001"
        };

        const signature = generateRedsysSignature(merchantParams, REDSYS_CONFIG.merchantKey);

        const insiteJSON = {
          id: "card-form",
          fuc: REDSYS_CONFIG.merchantCode,
          terminal: REDSYS_CONFIG.terminal,
          order: orderId,
          amount: totalInCents.toString(),
          currency: REDSYS_CONFIG.currency,
          transactionType: REDSYS_CONFIG.transactionType,
          merchantName: REDSYS_CONFIG.merchantName,
          merchantCode: REDSYS_CONFIG.merchantCode,
          merchantURL: `${window.location.origin}/api/redsys/notify`,
          successURL: `${window.location.origin}/success`,
          errorURL: `${window.location.origin}/error`,
          merchantData: signature, // Incluimos la firma como merchantData
          estiloInsite: "inline"
        };

        console.log('Initializing Redsys form...');
        window.getInSiteFormJSON(insiteJSON);
        setFormInitialized(true);
      } else {
        throw new Error('getInSiteFormJSON is not available');
      }
    } catch (err) {
      console.error('Error initializing Redsys form:', err);
      setError('Error al inicializar el formulario de pago');
    }
  };

  const handleScriptLoad = () => {
    console.log('Redsys script loaded');
    setScriptLoaded(true);
  };

  useEffect(() => {
    const handleMessage = async (event: MessageEvent) => {
      if (isProcessing) return;

      try {
        console.log('Payment message received:', event);
        
        if (window.storeIdOper) {
          setIsProcessing(true);
          
          window.storeIdOper(event, "token", "errorCode", () => {
            // Validación adicional aquí si es necesario
            try {
              // Limpiar datos después del pago exitoso
              localStorage.removeItem('checkoutData');
              localStorage.removeItem('cartTotal');
              // Aquí podrías agregar una llamada a tu API para registrar el pago
              return true;
            } catch (err) {
              console.error('Error processing payment:', err);
              return false;
            }
          });
        }
      } catch (err) {
        console.error('Error handling payment message:', err);
        setError('Error al procesar el pago');
      } finally {
        setIsProcessing(false);
      }
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [isProcessing]);

  if (!checkoutData) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-screen">
          <p className="text-gray-600">Redirigiendo al carrito...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <Script
        src={REDSYS_CONFIG.environment === 'test' 
          ? "https://sis-t.redsys.es:25443/sis/NC/sandbox/redsysV3.js"
          : "https://sis.redsys.es/sis/NC/redsysV3.js"}
        onLoad={handleScriptLoad}
        onError={() => setError("Error al cargar el script de Redsys")}
        strategy="afterInteractive"
      />
      
      <div className="container mx-auto py-20">
        <h1 className="text-2xl font-bold mb-4">Finalizar Compra</h1>
        
        {/* Resumen del pedido */}
        <div className="mb-6 p-6 bg-white rounded-lg shadow">
          <p className="font-bold text-lg mb-2">Resumen del Pedido</p>
          <div className="space-y-2">
            <p className="text-gray-600">Número de pedido: <span className="font-medium">{orderId}</span></p>
            <p className="text-xl font-bold">Total a pagar: {checkoutData.total.toFixed(2)}€</p>
          </div>
        </div>

        {/* Formulario de pago */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold">Formulario de Pago</h2>
          </div>
          
          <div id="card-form" className="p-6 min-h-[200px]">
            {!scriptLoaded && (
              <div className="flex items-center justify-center h-[200px]">
                <p className="text-gray-600">Cargando pasarela de pago...</p>
              </div>
            )}
            
            {scriptLoaded && !formInitialized && (
              <div className="flex items-center justify-center h-[200px]">
                <p className="text-gray-600">Inicializando formulario de pago...</p>
              </div>
            )}
          </div>

          {error && (
            <div className="p-4 mx-6 mb-6 bg-red-50 border border-red-200 rounded">
              <p className="text-red-600">{error}</p>
            </div>
          )}
        </div>

        {/* Información adicional */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-600">
            Serás redirigido a la pasarela de pago segura de Redsys para completar tu compra.
          </p>
        </div>
      </div>
    </Layout>
  );
}