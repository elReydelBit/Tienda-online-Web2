import { NextResponse } from 'next/server';
import { REDSYS_CONFIG } from '@/lib/redsys-config';
import { generateRedsysSignature } from '@/lib/redsys-utils';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { orderId, amount } = body;

    const merchantParams = {
      DS_MERCHANT_AMOUNT: amount,
      DS_MERCHANT_ORDER: orderId,
      DS_MERCHANT_MERCHANTCODE: REDSYS_CONFIG.merchantCode,
      DS_MERCHANT_CURRENCY: REDSYS_CONFIG.currency,
      DS_MERCHANT_TRANSACTIONTYPE: REDSYS_CONFIG.transactionType,
      DS_MERCHANT_TERMINAL: REDSYS_CONFIG.terminal,
      DS_MERCHANT_MERCHANTURL: `${request.headers.get('origin')}/api/redsys/notify`,
      DS_MERCHANT_URLOK: `${request.headers.get('origin')}/success`,
      DS_MERCHANT_URLKO: `${request.headers.get('origin')}/error`,
      DS_MERCHANT_MERCHANTNAME: REDSYS_CONFIG.merchantName,
      DS_MERCHANT_TITULAR: REDSYS_CONFIG.titular,
      DS_MERCHANT_CONSUMERLANGUAGE: "001"
    };

    const signature = generateRedsysSignature(merchantParams, REDSYS_CONFIG.merchantKey);
    const merchantParamsBase64 = Buffer.from(JSON.stringify(merchantParams)).toString('base64');

    const redsysPayload = {
      Ds_SignatureVersion: "HMAC_SHA256_V1",
      Ds_MerchantParameters: merchantParamsBase64,
      Ds_Signature: signature
    };

    const response = await fetch(REDSYS_CONFIG.urlAPI, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(redsysPayload)
    });

    if (!response.ok) {
      throw new Error('Error en la conexión con Redsys');
    }

    const responseData = await response.json();
    return NextResponse.json(responseData);

  } catch (error) {
    console.error('Error initiating Redsys transaction:', error);
    return NextResponse.json(
      { error: 'Error al iniciar la transacción' },
      { status: 500 }
    );
  }
}