// src/app/api/redsys/notify/route.ts
import { NextResponse } from 'next/server';
import { REDSYS_CONFIG } from '@/lib/redsys-config';
import { generateRedsysSignature } from '@/lib/redsys-utils';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { Ds_SignatureVersion, Ds_MerchantParameters, Ds_Signature } = body;

    const decodedParams = JSON.parse(Buffer.from(Ds_MerchantParameters, 'base64').toString());
    const calculatedSignature = generateRedsysSignature(decodedParams, REDSYS_CONFIG.merchantKey);

    if (Ds_Signature !== calculatedSignature) {
      throw new Error('Invalid signature');
    }

    // Procesar la respuesta según el código de respuesta
    const responseCode = decodedParams.Ds_Response;
    if (responseCode >= 0 && responseCode <= 99) {
      // Transacción autorizada
      // Aquí deberías actualizar tu base de datos
      console.log('Transacción autorizada:', decodedParams);
    } else {
      console.log('Transacción rechazada:', decodedParams);
    }

    return NextResponse.json({ status: 'OK' });

  } catch (error) {
    console.error('Error processing Redsys notification:', error);
    return NextResponse.json(
      { error: 'Error processing notification' },
      { status: 500 }
    );
  }
}